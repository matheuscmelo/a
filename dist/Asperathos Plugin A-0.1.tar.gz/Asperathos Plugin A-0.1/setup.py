from setuptools import setup

setup(
    name='Asperathos Plugin A',
    version='0.1',
    py_modules=['asperathos_plugin_a']
    )
